// header for spaceKeys.cpp
// Handle all the keys for the spacemouse

void readAllFromKeys(int* keyVals);
void setupKeys();
void evalKeys(int* keyVals, uint8_t* keyOut);
